import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demoapp';

  name = 'akul tripathi';

  data=false;

  emp= ['akul', 'sumit', 'sudhir']

  emps=[
    { "name": "akul", "des":"trainer", "city":"meerut"},
    { "name": "akul", "des":"trainer", "city":"meerut"},
    { "name": "akul", "des":"trainer", "city":"meerut"},
    { "name": "akul", "des":"trainer", "city":"meerut"},
  ]
}
